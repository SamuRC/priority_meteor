(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['preserve-inputs'] = {};

})();
